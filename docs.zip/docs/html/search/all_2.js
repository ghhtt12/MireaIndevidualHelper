var searchData=
[
  ['setup_2epy_0',['Setup.py',['../_setup_8py.html',1,'']]]
];
