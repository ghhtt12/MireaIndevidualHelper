var indexSectionsWithContent =
{
  0: "prstбиопст",
  1: "rs",
  2: "prt",
  3: "бпст"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Functions",
  3: "Pages"
};

