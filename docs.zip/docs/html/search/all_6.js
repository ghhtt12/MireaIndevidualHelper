var searchData=
[
  ['обзор_0',['Обзор',['../index.html#overview',1,'']]]
];
