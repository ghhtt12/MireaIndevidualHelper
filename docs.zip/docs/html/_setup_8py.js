var _setup_8py =
[
    [ "Setup.read_pipenv_dependencies", "_setup_8py.html#a665e9e0d2f357fd5fc7547a20e3929fd", null ]
];