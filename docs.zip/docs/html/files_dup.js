var files_dup =
[
    [ "rasp.py", "rasp_8py.html", "rasp_8py" ],
    [ "Setup.py", "_setup_8py.html", "_setup_8py" ]
];